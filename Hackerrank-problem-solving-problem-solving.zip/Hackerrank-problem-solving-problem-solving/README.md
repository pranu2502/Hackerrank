For any doubts regarding the problems in Hackerrank please refer the codes given.
